
<?php

error_reporting(0);
ini_set('display_errors', 0);


$servername = "localhost";
$username ="root";
$password = "";
$dbname = "task";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nammm=$_POST["user"];
    
    $email=$_POST["password"];




    
}



// Create connection
$conn = new mysqli($servername,$username, $password, $dbname);
// Check connection




$sql = "SELECT username, passwor FROM user ";
$result = $conn->query($sql);
$count =0;
if ($result->num_rows > 0) {
  // output data of each row

 
    while($row = $result->fetch_assoc()) {
  
        if($row["username"]== $nammm && $row["passwor"]== $email && $nammm !="" && $email!="" ) {
            session_start(); 
            $_SESSION["use"] = $row["username"];
            header("Location: home.php");
            
            
        }


}
  
    
    
  }
 

      
  
 
  



  
  

$conn->close();









?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>ِANAS ADEL ISMAL</title>
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.jpg" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body >

        <div id="maiiin" style="width: 100%;    padding-top: 50px;">

            <div id ="withimage" style="width:40%">  
                
                <img src="assets/img/log.png"  >
            
            </div>


            <div id="withform"   >
                   <div style="text-align: center; width:60%;margin-left: 20%;">


                    <h1 style="font-size: xx-large;">Join us by loging up </h1>
                    <h3 style="font-size: large; "> By login you be able to buy or sell your product in yemen app</h3>

                
                   </div>
                 
               
                <div style="width:60% ;height:100%; margin-left: 6%; margin-left: 20%;">
                   <form  action="login.php" method="POST" >
                       <label>user name:</label>
                       <input placeholder="user name"  type="text" name="user" style=" margin-bottom:2.9% ;background-color: #eff2f7; border: none; width: 100%; height: 30px; margin-top: 1.9%; border-radius: 5px;">
                       <label >password:</label>
                       <input  placeholder="password" type="password" name="password" style=" margin-bottom:2.9%;background-color: #eff2f7; border: none; width: 100%; height: 30px; margin-top: 1.9%; border-radius: 5px;">
                  
                       <input id="subbtn" type="submit" value="login" name="sub"  style="width: 130px;"  >
                       
                  
                  
                  
                       </form>
           
           
           
                </div>
               
               </div>
         


            

        </div>
       
  
          <div id="loginn"  >


            <p >  have not an acount <a href="index.php" style="color: red;">signin </a></p>


         </div> 
    

   

    
        

    
    </body>
</html>
