<!DOCTYPE html>

<?php
error_reporting(0);
ini_set('display_errors', 0);

$servername = "localhost";
$username ="root";
$password ="";
$dbname = "task";
$color= "#d9d9d9";
$conn = new mysqli($servername,$username, $password, $dbname);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	
	$user=$_POST["user"];
	$pas=$_POST["passwordo"];
	$email=$_POST["email"];
	
	}


    $sql = "SELECT username, passwor FROM user where username = '$user'";
    $result = $conn->query($sql);
    $count =0;
    if ($result->num_rows > 0) {
      // output data of each row
    

               
            echo " there is user with same name ";

                
                
    }
    else if( $pas!=""&&$email!=""&&$user!=""){


                $sql = "INSERT INTO user (username,passwor, email)
                VALUES ('$user', '$pas','$email')";
                 
                
                
                $conn->query($sql);
                
                $conn->close();
            
            
                header('Location: login.php');
            
            
             }
             
            
    
    
    
      
        
        
      





 
?>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>ِANAS ADEL ISMAL</title>
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.jpg" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body >

        <div id="maiiin" style="width: 100%;   align-items: center; padding-top: 50px;">

            <div id ="withimage" >  
                
                <img src="assets/img/b2new.png" >
            
            </div>


            <div id="withform"   >
                   <div style="text-align: center; width:60%;margin-left: 20%;">


                    <h1 style="font-size: xx-large;">Join us by signin up </h1>
                    <h3 style="font-size: large; "> By signup you be able to buy or sell your product in yemen app</h3>

                
                   </div>
                 
               
                <div style="width:60% ;height:100%; margin-left: 6%; margin-left: 20%;">
                   <form action="index.php" method="POST" >
                       <label>user name:</label>
                       <input placeholder="user name"  type="text" name="user" style=" margin-bottom:2.9% ;background-color: #eff2f7; border: none; width: 100%; height: 30px; margin-top: 1.9%; border-radius: 5px;">
                       <label >Email address:</label>
                       <input placeholder="Email address" type="email" name="email" style=" margin-bottom:2.9% ;background-color: #eff2f7; border: none; width: 100%; height: 30px; margin-top: 1.9%;border-radius: 5px;" >
                       <label >password:</label>
                       <input  placeholder="password" type="password" name="passwordo" style=" margin-bottom:2.9%;background-color: #eff2f7; border: none; width: 100%; height: 30px; margin-top: 1.9%; border-radius: 5px;">
                  
                       <input id="subbtn" type="submit" value="signin" name="password"  style="width: 130px;"  >
                       
                  
                  
                  
                       </form>
           
           
           
                </div>
               
               </div>
         


            

        </div>
       
  
          <div id="loginn"  >


            <p > Already have an acount <a href="login.php" style="color: red;">login </a></p>


         </div> 
    

   

    
        

    
    </body>
</html>
