const ll= document.querySelector("#searc");
const search=document.querySelector("#search_box");
ll.addEventListener(
'click',function(){

    console.log("SSssa");
if(search.classList.contains("show")){

    search.classList.remove("show");


}
else{

    search.classList.add("show");


}
   
   
    
}
)


